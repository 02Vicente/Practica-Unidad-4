﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Practica_IV_II.Models;


namespace Practica_IV_III.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Index(FormCollection collection)
        {
            MantenimientoProducto mp = new MantenimientoProducto();
            Producto prod = mp.BucarProducto(int.Parse(collection["IdProducto"].ToString()));
            if (prod != null)
                return View("Modificar", prod);
            else
                return View("ProductonoExiste");
        }


        [HttpPost]
        public ActionResult Modificar(FormCollection collection)
        {
            MantenimientoProducto mp = new MantenimientoProducto();
            Producto prod = new Producto
            {
                IdProducto = int.Parse(collection["IdProducto"].ToString()),
                Descripcion = collection["Descripcion"].ToString(),
                Tipo = collection["Tipo"].ToString(),
                Precio = float.Parse(collection["Precio"].ToString())
            };
            mp.ModificarProducto(prod);
            return RedirectToAction("Index");
        }

        public ActionResult Agregar()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Agregar(FormCollection collection)
        {
            MantenimientoProducto mp = new MantenimientoProducto();
            Producto prod = new Producto
            {
                IdProducto = int.Parse(collection["IdProducto"].ToString()),
                Descripcion = collection["Descripcion"],
                Tipo = collection["Tipo"],
                Precio = float.Parse(collection["Precio"].ToString())
            };
            mp.AgregarProducto(prod);
            return RedirectToAction("Index");
        }


        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
    }
}