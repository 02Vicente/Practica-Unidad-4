﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Practica_IV_II.Models
{
    public class Producto
    {
        public int IdProducto { get; set; }
        public string Descripcion { get; set; }
        public string Tipo { get; set; }
        public float Precio { get; set; }
    }
}