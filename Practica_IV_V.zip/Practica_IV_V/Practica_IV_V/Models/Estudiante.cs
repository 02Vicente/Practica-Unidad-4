﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Practica_IV_V.Models
{
    public class Estudiante
    {
        [Required(ErrorMessage ="El Nombre es Obligatorio")]
        [MinLength(3, ErrorMessage ="El Nombre del Estudiante debe tener al menos 3 caracteres")]
        public string Nombre { get; set; }

        [Required(ErrorMessage = "El Apellido es Obligatorio")]
        [MinLength(2, ErrorMessage = "El Apellido del Estudiante debe tener al menos 2 caracteres")]
        public string Apellido { get; set; }

        [Range(14,65, ErrorMessage = "La edad del Estudiante debe estar entre 14 y 65")]
        public int Edad { get; set; }

        [EmailAddress(ErrorMessage ="Debe ingresar un email valido")]
        public string Email { get; set; }

        [RegularExpression("[MmFf]", ErrorMessage ="Solo Puedeo ingresar una M=Masculino o una F=Femenino")]
        public string Genero { get; set; }

        [RegularExpression("[CcSsUuDd]", ErrorMessage = "Solo Puedeo ingresar una C=Casado, S=Soltero, U=Unico Libre o D=Divorciado")]
        public string EstadoCivil { get; set; }
    }
}